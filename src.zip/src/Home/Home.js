import React from 'react';
const Home=() => {
    return(
        <h1>Customer</h1>
    )
}
export default Home;